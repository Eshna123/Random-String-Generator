# Random String App

This is a sample project for the IAV Android Challenge.